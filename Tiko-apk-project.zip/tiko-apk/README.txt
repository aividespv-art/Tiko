Tiko APK project (Capacitor)
1) Upload this folder to a new GitHub repository (include the .github folder).
2) Open the Actions tab > "Build Tiko APK" > Run workflow.
3) When finished, download "Tiko-apk" from Artifacts, unzip, install app-debug.apk.
Local build alternative: npm install && npx cap add android && npx @capacitor/assets generate --android && npx cap sync && open android/ in Android Studio > Build APK.
